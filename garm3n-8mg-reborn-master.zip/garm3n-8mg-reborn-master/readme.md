# Garm3n-8MG
An updated version of Garm3n 8MG as requested by Emily Vasquez. It will be continuously updated to bring it closer to modern standards while retaining it's blend of minimalism and stylization.

NOTE FOR EPILEPTIC USERS: When using items that cause you to gradually re-gain drained health after holstering them, the health text will rapidly flash white and green which can possibly lead to sickness or even a seizure.

Screenshots: https://imgur.com/a/0Mn7x

How to Download and Install: https://imgur.com/a/w3Ah6
